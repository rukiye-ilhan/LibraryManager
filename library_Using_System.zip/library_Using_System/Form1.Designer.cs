﻿namespace library_Using_System
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtname = new System.Windows.Forms.TextBox();
			this.txtsurname = new System.Windows.Forms.TextBox();
			this.txtemail = new System.Windows.Forms.TextBox();
			this.txtphone = new System.Windows.Forms.TextBox();
			this.txtbirthdate = new System.Windows.Forms.TextBox();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.btn_add = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.btn = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtname
			// 
			this.txtname.Location = new System.Drawing.Point(442, 21);
			this.txtname.Name = "txtname";
			this.txtname.Size = new System.Drawing.Size(239, 22);
			this.txtname.TabIndex = 0;
			// 
			// txtsurname
			// 
			this.txtsurname.Location = new System.Drawing.Point(442, 66);
			this.txtsurname.Name = "txtsurname";
			this.txtsurname.Size = new System.Drawing.Size(239, 22);
			this.txtsurname.TabIndex = 0;
			// 
			// txtemail
			// 
			this.txtemail.Location = new System.Drawing.Point(442, 107);
			this.txtemail.Name = "txtemail";
			this.txtemail.Size = new System.Drawing.Size(239, 22);
			this.txtemail.TabIndex = 0;
			// 
			// txtphone
			// 
			this.txtphone.Location = new System.Drawing.Point(442, 152);
			this.txtphone.Name = "txtphone";
			this.txtphone.Size = new System.Drawing.Size(239, 22);
			this.txtphone.TabIndex = 0;
			// 
			// txtbirthdate
			// 
			this.txtbirthdate.Location = new System.Drawing.Point(442, 195);
			this.txtbirthdate.Name = "txtbirthdate";
			this.txtbirthdate.Size = new System.Drawing.Size(239, 22);
			this.txtbirthdate.TabIndex = 0;
			// 
			// radioButton1
			// 
			this.radioButton1.AutoSize = true;
			this.radioButton1.Location = new System.Drawing.Point(442, 239);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(62, 20);
			this.radioButton1.TabIndex = 1;
			this.radioButton1.TabStop = true;
			this.radioButton1.Text = "Kadın";
			this.radioButton1.UseVisualStyleBackColor = true;
			// 
			// radioButton2
			// 
			this.radioButton2.AutoSize = true;
			this.radioButton2.Location = new System.Drawing.Point(608, 239);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(63, 20);
			this.radioButton2.TabIndex = 1;
			this.radioButton2.TabStop = true;
			this.radioButton2.Text = "Erkek";
			this.radioButton2.UseVisualStyleBackColor = true;
			// 
			// btn_add
			// 
			this.btn_add.Location = new System.Drawing.Point(526, 316);
			this.btn_add.Name = "btn_add";
			this.btn_add.Size = new System.Drawing.Size(155, 57);
			this.btn_add.TabIndex = 2;
			this.btn_add.Text = "Üye Ol";
			this.btn_add.UseVisualStyleBackColor = true;
			this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(347, 26);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(31, 16);
			this.label1.TabIndex = 3;
			this.label1.Text = "İsim";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(347, 66);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(55, 16);
			this.label2.TabIndex = 3;
			this.label2.Text = "Soyisim";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(347, 107);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(41, 16);
			this.label3.TabIndex = 3;
			this.label3.Text = "Email";
			this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(322, 155);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(114, 16);
			this.label4.TabIndex = 3;
			this.label4.Text = "Telefon Numarası";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(347, 195);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(88, 16);
			this.label5.TabIndex = 3;
			this.label5.Text = "Doğum Tarihi";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(347, 239);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(54, 16);
			this.label6.TabIndex = 3;
			this.label6.Text = "Cinsiyet";
			// 
			// btn
			// 
			this.btn.Location = new System.Drawing.Point(22, 26);
			this.btn.Name = "btn";
			this.btn.Size = new System.Drawing.Size(242, 148);
			this.btn.TabIndex = 4;
			this.btn.Text = "Kütphane işlemleri için tıklyanız";
			this.btn.UseVisualStyleBackColor = true;
			this.btn.Click += new System.EventHandler(this.btn_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.btn);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btn_add);
			this.Controls.Add(this.radioButton2);
			this.Controls.Add(this.radioButton1);
			this.Controls.Add(this.txtbirthdate);
			this.Controls.Add(this.txtphone);
			this.Controls.Add(this.txtemail);
			this.Controls.Add(this.txtsurname);
			this.Controls.Add(this.txtname);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtname;
		private System.Windows.Forms.TextBox txtsurname;
		private System.Windows.Forms.TextBox txtemail;
		private System.Windows.Forms.TextBox txtphone;
		private System.Windows.Forms.TextBox txtbirthdate;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.Button btn_add;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button btn;
	}
}

