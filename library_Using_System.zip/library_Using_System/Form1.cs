﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace library_Using_System
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}
		SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GI1C2ED\\SQLEXPRESS01;" +
		"Initial Catalog=library_DB_app; Integrated Security=True");

		private void btn_add_Click(object sender, EventArgs e)
		{
			if (conn.State == ConnectionState.Closed)
				conn.Open();
			SqlCommand cmd = new SqlCommand("INSERT INTO Uyeler (Ad, Soyad, Telefon, Email, Cinsiyet, Birthdate) VALUES ('" + txtname.Text + "','" + txtsurname.Text + "','" + txtphone.Text + "','" + txtemail.Text + "','" + radioButton1.Text + "','" + txtbirthdate.Text + "')", conn);
			cmd.ExecuteNonQuery();
			MessageBox.Show(txtname.Text + " " + txtsurname.Text + " " + "İsimli üyemiz başarıyla sisteme kaydedildiniz");

		}

		private void btn_Click(object sender, EventArgs e)
		{
			Form2 form2 = new Form2();
			form2.Show();
		}
	}
}
