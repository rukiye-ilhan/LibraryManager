﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace library_Using_System
{
	public partial class Form2 : Form
	{
		public Form2()
		{
			InitializeComponent();
		}
		SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GI1C2ED\\SQLEXPRESS01;" +
		"Initial Catalog=library_DB_app; Integrated Security=True");

		private void Form2_Load(object sender, EventArgs e)
		{
			// Form2 açıldığında yazar isimlerini ComboBox1'e doldur
			string query = "SELECT Ad  AS YazarAdi FROM Yazarlar";
			SqlCommand command = new SqlCommand(query, conn);

			try
			{
				conn.Open();
				SqlDataReader reader = command.ExecuteReader();
				while (reader.Read())
				{
					comboBox1.Items.Add(reader["YazarAdi"].ToString());
				}
				reader.Close();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Yazarlar yüklenirken hata: " + ex.Message);
			}

			// Kitap türlerini ComboBox2'ye doldur
			string query1 = "SELECT TurAdi FROM KitapTurleri";
			SqlCommand command1 = new SqlCommand(query1, conn);

			try
			{
				SqlDataReader reader1 = command1.ExecuteReader();
				while (reader1.Read())
				{
					comboBox2.Items.Add(reader1["TurAdi"].ToString());
				}
				reader1.Close();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Kitap türleri yüklenirken hata: " + ex.Message);
			}
			finally
			{
				conn.Close(); // Bağlantıyı kapatmayı unutmayın
			}

		}

		private void btn_list_Click(object sender, EventArgs e)
		{
			/*string query = "SELECT  k.Ad AS KitapAdi, k.BasimYili, k.ISBN, y.Ad + ' ' + y.Soyad AS YazarAdi, t.TurAdi FROM " +
				" Kitaplar k JOIN  Yazarlar y ON k.YazarId = y.Id JOIN  KitapTurleri t ON k.TurId = t.Id" +
				" WHERE     y.Id = @YazarId AND t.Id = @TurId";*/
			if (conn.State == ConnectionState.Closed)
				conn.Open();
			string query = @"
					SELECT 
						k.KitapId, 
						k.Ad AS KitapAdi, 
						k.BasimYili, 
						k.ISBN, 
						y.Ad AS YazarAdi ,
						t.TurAdi,
						o.UyeId
					FROM 
						Kitaplar k
					JOIN 
						Yazarlar y ON k.YazarId = y.YazarId
					JOIN 
						KitapTurleri t ON k.TurId = t.TurId
					JOIN 
						OduncAlma o ON k.KitapId = o.KitapId
					WHERE 
						y.Ad = @p1 AND t.TurAdi = @p2";


			SqlCommand command = new SqlCommand(query, conn);
			command.Parameters.AddWithValue("@p1", comboBox1.SelectedItem);
			command.Parameters.AddWithValue("@p2", comboBox2.SelectedItem);

			try
			{
				SqlDataAdapter adapter = new SqlDataAdapter(command);
				DataSet ds = new DataSet();
				adapter.Fill(ds);
				// DataGridView'e veri kaynağını bağla
				dataGridView1.DataSource = ds.Tables[0];
			}
			catch (Exception ex)
			{
				MessageBox.Show("Kitaplar listelenirken hata: " + ex.Message);
			}
		}
		// Seçilen satırlardaki kitap bilgilerini almak
		string KitapAdi = "";
		string YazarAdi = "";
		string TurAdi = "";
		string KitapId = "";
		string UyeId = "";
		private void btn_barrow_Click(object sender, EventArgs e)
		{
			Form3 form3 = new Form3(KitapId, KitapAdi, YazarAdi, TurAdi, UyeId);
			form3.Show();

		}
		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			// Seçilen satırdan verileri al
			if (e.RowIndex >= 0) // Geçerli bir satır kontrolü
			{
				//DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
				KitapId = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
				KitapAdi = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
				YazarAdi = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
				TurAdi = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
				UyeId = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString(); // Bu, UyeId değilse düzeltin
			}
		}
	}
}
