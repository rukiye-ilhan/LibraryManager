﻿namespace library_Using_System
{
	partial class Form3
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtauthorname = new System.Windows.Forms.TextBox();
			this.txtbookname = new System.Windows.Forms.TextBox();
			this.txtgendername = new System.Windows.Forms.TextBox();
			this.txtkitapıd = new System.Windows.Forms.TextBox();
			this.txtuyeıd = new System.Windows.Forms.TextBox();
			this.txtname = new System.Windows.Forms.TextBox();
			this.txtsurname = new System.Windows.Forms.TextBox();
			this.btn_confrim = new System.Windows.Forms.Button();
			this.btn_search = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtauthorname
			// 
			this.txtauthorname.Location = new System.Drawing.Point(143, 31);
			this.txtauthorname.Name = "txtauthorname";
			this.txtauthorname.Size = new System.Drawing.Size(100, 22);
			this.txtauthorname.TabIndex = 0;
			// 
			// txtbookname
			// 
			this.txtbookname.Location = new System.Drawing.Point(143, 59);
			this.txtbookname.Name = "txtbookname";
			this.txtbookname.Size = new System.Drawing.Size(100, 22);
			this.txtbookname.TabIndex = 0;
			// 
			// txtgendername
			// 
			this.txtgendername.Location = new System.Drawing.Point(143, 87);
			this.txtgendername.Name = "txtgendername";
			this.txtgendername.Size = new System.Drawing.Size(100, 22);
			this.txtgendername.TabIndex = 0;
			// 
			// txtkitapıd
			// 
			this.txtkitapıd.Location = new System.Drawing.Point(143, 115);
			this.txtkitapıd.Name = "txtkitapıd";
			this.txtkitapıd.Size = new System.Drawing.Size(100, 22);
			this.txtkitapıd.TabIndex = 0;
			// 
			// txtuyeıd
			// 
			this.txtuyeıd.Location = new System.Drawing.Point(143, 143);
			this.txtuyeıd.Name = "txtuyeıd";
			this.txtuyeıd.Size = new System.Drawing.Size(100, 22);
			this.txtuyeıd.TabIndex = 0;
			// 
			// txtname
			// 
			this.txtname.Location = new System.Drawing.Point(471, 30);
			this.txtname.Name = "txtname";
			this.txtname.Size = new System.Drawing.Size(100, 22);
			this.txtname.TabIndex = 1;
			// 
			// txtsurname
			// 
			this.txtsurname.Location = new System.Drawing.Point(471, 87);
			this.txtsurname.Name = "txtsurname";
			this.txtsurname.Size = new System.Drawing.Size(100, 22);
			this.txtsurname.TabIndex = 1;
			// 
			// btn_confrim
			// 
			this.btn_confrim.Location = new System.Drawing.Point(471, 136);
			this.btn_confrim.Name = "btn_confrim";
			this.btn_confrim.Size = new System.Drawing.Size(158, 36);
			this.btn_confrim.TabIndex = 2;
			this.btn_confrim.Text = "Ödünç İşlemi Onayla";
			this.btn_confrim.UseVisualStyleBackColor = true;
			this.btn_confrim.Click += new System.EventHandler(this.btn_confrim_Click);
			// 
			// btn_search
			// 
			this.btn_search.Location = new System.Drawing.Point(471, 195);
			this.btn_search.Name = "btn_search";
			this.btn_search.Size = new System.Drawing.Size(158, 51);
			this.btn_search.TabIndex = 3;
			this.btn_search.Text = "max kitap sorgula";
			this.btn_search.UseVisualStyleBackColor = true;
			this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(25, 30);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(65, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "Yazar Adı";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(25, 65);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(60, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Kitap Adı";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(25, 93);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(50, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Tür Adı";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(25, 121);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(71, 16);
			this.label4.TabIndex = 4;
			this.label4.Text = "Kitap Kodu";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(383, 37);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(53, 16);
			this.label5.TabIndex = 4;
			this.label5.Text = "İsminiz :";
			this.label5.Click += new System.EventHandler(this.label5_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(383, 93);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(77, 16);
			this.label6.TabIndex = 4;
			this.label6.Text = "Soyisminiz :";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(25, 156);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(66, 16);
			this.label7.TabIndex = 4;
			this.label7.Text = "Üye Kodu";
			// 
			// Form3
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btn_search);
			this.Controls.Add(this.btn_confrim);
			this.Controls.Add(this.txtsurname);
			this.Controls.Add(this.txtname);
			this.Controls.Add(this.txtuyeıd);
			this.Controls.Add(this.txtkitapıd);
			this.Controls.Add(this.txtgendername);
			this.Controls.Add(this.txtbookname);
			this.Controls.Add(this.txtauthorname);
			this.Name = "Form3";
			this.Text = "Form3";
			this.Load += new System.EventHandler(this.Form3_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtauthorname;
		private System.Windows.Forms.TextBox txtbookname;
		private System.Windows.Forms.TextBox txtgendername;
		private System.Windows.Forms.TextBox txtkitapıd;
		private System.Windows.Forms.TextBox txtuyeıd;
		private System.Windows.Forms.TextBox txtname;
		private System.Windows.Forms.TextBox txtsurname;
		private System.Windows.Forms.Button btn_confrim;
		private System.Windows.Forms.Button btn_search;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
	}
}