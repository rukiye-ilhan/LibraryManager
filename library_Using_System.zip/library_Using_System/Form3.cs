﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace library_Using_System
{
	public partial class Form3 : Form
	{
		// Constructor ile alınacak değişkenler
		string KitapAdi;
		string YazarAdi;
		string TurAdi;
		string KitapId;
		string UyeId;

		// Constructor
		public Form3(string kitapId, string kitapAdi, string yazarAdi, string turAdi, string uyeId)
		{
			InitializeComponent();

			// Parametreleri sınıf değişkenlerine ata
			this.KitapId = kitapId;
			this.KitapAdi = kitapAdi;
			this.YazarAdi = yazarAdi;
			this.TurAdi = turAdi;
			this.UyeId = uyeId;
		}

		// Form yüklendiğinde TextBox'ları doldur
		private void Form3_Load(object sender, EventArgs e)
		{
			txtauthorname.Text = YazarAdi;   // Yazar adı TextBox
			txtbookname.Text = KitapAdi;    // Kitap adı TextBox
			txtgendername.Text = TurAdi;    // Tür adı TextBox
			txtkitapıd.Text = KitapId;      // Kitap ID TextBox
			txtuyeıd.Text = UyeId;          // Üye ID TextBox
		}
		SqlConnection conn = new SqlConnection("Data Source=DESKTOP-GI1C2ED\\SQLEXPRESS01;" +
		"Initial Catalog=library_DB_app; Integrated Security=True");
		private void btn_confrim_Click(object sender, EventArgs e)
		{

			if (conn.State == ConnectionState.Closed)
				conn.Open();
			//string timequery = "SELECT U.Ad +' ' +U.Soyad AS UyeAdSoyad, DATEDIFF(DAY,OduncTarihi, OA.TeslimTarihi) AS GecikmeSüresi FROM OduncAlma OA JOIN Uyeler U ON U.UyeId=OA.UyeId JOIN Kitaplar K ON K.KitapId=OA.KitapId WHERE OA.Durum=1 AND DATEDIFF(DAY,OduncTarihi, OA.TeslimTarihi) >= 15 AND UyeAdSoyad = '" + txtname + txtsurname + "'";
			string timequery =
						@"
				SELECT 
					U.Ad + ' ' + U.Soyad AS UyeAdSoyad, 
					DATEDIFF(DAY, OduncTarihi, OA.TeslimTarihi) AS GecikmeSuresi 
				FROM 
					OduncAlma OA 
				JOIN 
					Uyeler U ON U.UyeId = OA.UyeId 
				JOIN 
					Kitaplar K ON K.KitapId = OA.KitapId 
				WHERE 
					OA.Durum = 1 
					AND DATEDIFF(DAY, OduncTarihi, OA.TeslimTarihi) >= 15 
					AND (U.Ad = @Ad AND U.Soyad = @Soyad)";

			SqlCommand cmd = new SqlCommand(timequery, conn);
			cmd.Parameters.AddWithValue("@Ad", txtname.Text);
			cmd.Parameters.AddWithValue("@Soyad", txtsurname.Text);

			SqlDataReader reader = cmd.ExecuteReader();
			if (reader.HasRows) // Eğer sorgu değer döndürüyorsa
			{
				while (reader.Read())
				{
					int gecikmeSuresi = Convert.ToInt32(reader["GecikmeSuresi"]);
					int beklemeSuresi = gecikmeSuresi - 15; // Gecikme süresi - 15 gün hesaplanıyor
					MessageBox.Show($"Teslim gecikmesi nedeniyle şu anda kitap alamazsınız. {beklemeSuresi} gün sonra tekrar kitap alabilirsiniz.");
				}
			}
			else // Sorgu boşsa
			{
				MessageBox.Show("Kitap ödünç alabilirsiniz.");

				// Kullanıcı adı, soyadı ve kitap adı alındıktan sonra, bu bilgileri OduncAlma tablosuna eklemek için aşağıdaki sorguyu kullanabilirsiniz.
				string insertQuery = @"
						INSERT INTO OduncAlma (KitapID, UyeID, OduncTarihi, TeslimTarihi, Durum) 
						VALUES (@KitapID, @UyeID, @OduncTarihi, @TeslimTarihi, @Durum)";
				// Veritabanı komutunu oluşturun
				SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
				// Parametreleri ekleyin
				// Anlık tarih bilgisini al
				DateTime oduncTarihi = DateTime.Now;

				// Ödünç tarihine 15 gün ekle
				DateTime teslimTarihi = oduncTarihi.AddDays(15);
				insertCmd.Parameters.AddWithValue("@KitapID", txtkitapıd); // Seçilen kitap id'si
				insertCmd.Parameters.AddWithValue("@UyeID", txtuyeıd); // Kullanıcı id'si
				insertCmd.Parameters.AddWithValue("@OduncTarihi", oduncTarihi); // Ödünç alınma tarihi
				insertCmd.Parameters.AddWithValue("@TeslimTarihi", teslimTarihi); // Teslim tarihi
				insertCmd.Parameters.AddWithValue("@Durum", 1); // Durum, ödünç alınan kitap için '1' olabilir

				// Komutu çalıştır
				insertCmd.ExecuteNonQuery();

				// Kullanıcıya başarı mesajı ver
				MessageBox.Show("Kitap başarıyla ödünç alındı.");
			}

			reader.Close();

	

		}

		private void btn_search_Click(object sender, EventArgs e)
		{

			if (conn.State == ConnectionState.Closed)
				conn.Open();

			string query = "SELECT  u.Ad, u.Soyad,COUNT(oa.KitapID) AS OduncAlinanKitapSayisi FROM  Uyeler LEFT JOIN OduncAlma oa ON u.UyeID = oa.UyeID AND oa.Durum = 1 WHERE  u.Ad = '" + txtname.Text + "' AND u.Soyad = '" + txtsurname.Text + " GROUP BY u.Ad, u.Soyad";
			SqlCommand cmd = new SqlCommand(query, conn);
			int oduncAlinanKitapSayisi = (int)cmd.ExecuteScalar();
			// Kullanıcının ödünç alabileceği kitap sayısını kontrol et
			if (oduncAlinanKitapSayisi >= 2)
			{
				MessageBox.Show("Zaten 2 kitap ödünç almışsınız. Daha fazla kitap alamazsınız.");
				return;
			}
			else if (oduncAlinanKitapSayisi == 1)
			{
				MessageBox.Show("Bir kitap ödünç almışsınız. Sadece bir kitap daha alabilirsiniz.");
				return;
			}
			else
			{
				// Kullanıcı daha önce kitap almamışsa, 2 kitap alabilecektir
				MessageBox.Show("Kitap ödünç alabilirsiniz.");

				// Kullanıcı adı, soyadı ve kitap adı alındıktan sonra, bu bilgileri OduncAlma tablosuna eklemek için aşağıdaki sorguyu kullanabilirsiniz.
				string insertQuery = @"
						INSERT INTO OduncAlma (KitapID, UyeID, OduncTarihi, TeslimTarihi, Durum) 
						VALUES (@KitapID, @UyeID, @OduncTarihi, @TeslimTarihi, @Durum)";
				// Veritabanı komutunu oluşturun
				SqlCommand insertCmd = new SqlCommand(insertQuery, conn);
				// Parametreleri ekleyin
				// Anlık tarih bilgisini al
				DateTime oduncTarihi = DateTime.Now;

				// Ödünç tarihine 15 gün ekle
				DateTime teslimTarihi = oduncTarihi.AddDays(15);
				insertCmd.Parameters.AddWithValue("@KitapID", txtkitapıd); // Seçilen kitap id'si
				insertCmd.Parameters.AddWithValue("@UyeID", txtuyeıd); // Kullanıcı id'si
				insertCmd.Parameters.AddWithValue("@OduncTarihi", oduncTarihi); // Ödünç alınma tarihi
				insertCmd.Parameters.AddWithValue("@TeslimTarihi", teslimTarihi); // Teslim tarihi
				insertCmd.Parameters.AddWithValue("@Durum", 1); // Durum, ödünç alınan kitap için '1' olabilir

				// Komutu çalıştır
				insertCmd.ExecuteNonQuery();

				// Kullanıcıya başarı mesajı ver
				MessageBox.Show("Kitap başarıyla ödünç alındı.");

			}

		}

		private void label5_Click(object sender, EventArgs e)
		{

		}

		
	}
}
